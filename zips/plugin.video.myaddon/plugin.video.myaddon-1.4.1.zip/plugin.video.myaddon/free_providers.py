import requests
import urllib.parse

def get_movie_torrents(imdb_id):
    """
    Scrape Torrents from Torrentio and YTS for Movies
    """
    streams = []
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'}
    
    # 1. Torrentio API
    url = f"https://torrentio.strem.fun/stream/movie/{imdb_id}.json"
    try:
        response = requests.get(url, headers=headers, timeout=10)
        data = response.json()
        streams.extend(_parse_streams(data.get('streams', [])))
    except Exception as e:
        print(f"Torrentio Movie Error: {e}")
        
    # 2. YTS API
    yts_url = f"https://yts.mx/api/v2/movie_details.json?imdb_id={imdb_id}"
    try:
        yts_resp = requests.get(yts_url, headers=headers, timeout=10)
        yts_data = yts_resp.json()
        for torrent in yts_data.get('data', {}).get('movie', {}).get('torrents', []):
            hash = torrent.get('hash')
            quality = torrent.get('quality')
            size = torrent.get('size')
            if hash:
                title = f"[YTS.mx] {quality} ({size})"
                magnet = f"magnet:?xt=urn:btih:{hash}&dn={imdb_id}"
                streams.append({
                    'title': title,
                    'magnet': magnet,
                    'info_hash': hash
                })
    except Exception as e:
        print(f"YTS Error: {e}")

    return streams

def get_tv_torrents(imdb_id, season, episode):
    """
    Scrape Torrents from Torrentio and EZTV for TV Shows
    """
    streams = []
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'}
    
    # 1. Torrentio API
    url = f"https://torrentio.strem.fun/stream/series/{imdb_id}:{season}:{episode}.json"
    try:
        response = requests.get(url, headers=headers, timeout=10)
        data = response.json()
        streams.extend(_parse_streams(data.get('streams', [])))
    except Exception as e:
        print(f"Torrentio TV Error: {e}")
        
    # 2. EZTV API
    eztv_url = f"https://eztvx.to/api/get-torrents?imdb_id={imdb_id.replace('tt', '')}"
    try:
        eztv_resp = requests.get(eztv_url, headers=headers, timeout=10)
        eztv_data = eztv_resp.json()
        for torrent in eztv_data.get('torrents', []):
            if str(torrent.get('season', '')) == str(season) and str(torrent.get('episode', '')) == str(episode):
                hash = torrent.get('hash')
                filename = torrent.get('title')
                if hash:
                    title = f"[EZTV.to] {filename}"
                    magnet = torrent.get('magnet_url', f"magnet:?xt=urn:btih:{hash}&dn={urllib.parse.quote(filename)}")
                    streams.append({
                        'title': title,
                        'magnet': magnet,
                        'info_hash': hash
                    })
    except Exception as e:
        print(f"EZTV Error: {e}")
        
    return streams

def _parse_streams(streams):
    parsed = []
    for stream in streams:
        if 'infoHash' in stream:
            info_hash = stream['infoHash']
            title = stream.get('title', 'Unknown Title')
            # Extract basic quality or name from the "name" or "title" field
            name = stream.get('name', 'Torrent')
            
            # Create standard magnet URI
            dn = urllib.parse.quote(title.split('\n')[0])
            magnet = f"magnet:?xt=urn:btih:{info_hash}&dn={dn}"
            
            # Format display title
            display_title = f"[{name.replace(chr(10), ' ')}] {title.split(chr(10))[0]}"
            
            parsed.append({
                'title': display_title,
                'magnet': magnet,
                'info_hash': info_hash
            })
    return parsed
