import requests
import re
import urllib.parse
from bs4 import BeautifulSoup

def extract_video_link(embed_url):
    """
    Attempts to extract the raw video file link (.mp4, .m3u8) from a web player URL.
    This acts as a "personal debrid" resolving the iframe to a stream.
    """
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
        'Referer': embed_url
    }
    
    try:
        # Step 1: Fetch the HTML of the embed page
        response = requests.get(embed_url, headers=headers, timeout=10)
        html = response.text
        
        # Step 2: Use regex to find common stream patterns in the Javascript or HTML
        # Look for .m3u8 or .mp4 files wrapped in quotes
        match = re.search(r'["\'](https?://[^"\']*\.(?:m3u8|mp4)[^"\']*)["\']', html)
        if match:
            # We found a direct media link!
            stream_url = match.group(1).replace('\\/', '/')
            return stream_url
            
        # Step 3: Look for iframes (if the embed redirects to another embed, like Mixdrop)
        soup = BeautifulSoup(html, 'html.parser')
        iframes = soup.find_all('iframe')
        for iframe in iframes:
            src = iframe.get('src')
            if src and 'http' in src:
                # If we were using resolveurl, we could pass this iframe src to it
                # For this raw extractor, we'll just check if it's a known host
                if 'mixdrop' in src or 'upstream' in src:
                    # In a real add-on, we would either call resolveurl here,
                    # or recursively call extract_video_link (if we wrote custom bypasses)
                    pass

    except Exception as e:
        print(f"Extraction failed for {embed_url}: {e}")
        
    return None
