import xbmc
import xbmcgui
import xbmcaddon
import os
import zipfile
import urllib.request

def install_elementum():
    try:
        xbmcaddon.Addon("plugin.video.elementum")
        return
    except:
        pass
        
    dialog = xbmcgui.Dialog()
    if not dialog.yesno("My Custom Add-on Setup", "To watch movies online instantly, the free Elementum streaming engine must be installed.\nWould you like to automatically download and install it now? (Takes 1-2 mins)"):
        return
        
    pDialog = xbmcgui.DialogProgress()
    pDialog.create("Installing Elementum", "Downloading from official GitHub...")
    pDialog.update(0)
    
    elementum_url = "https://github.com/elgatito/plugin.video.elementum/releases/download/v0.1.87/plugin.video.elementum-0.1.87.zip"
    zip_path = xbmc.translatePath("special://temp/elementum.zip")
    
    try:
        def reporthook(count, block_size, total_size):
            if total_size > 0:
                percent = int(count * block_size * 100 / total_size)
                if percent > 100:
                    percent = 100
                pDialog.update(percent, f"Downloading... {percent}%")
                
        urllib.request.urlretrieve(elementum_url, zip_path, reporthook)
        
        pDialog.update(100, "Extracting to Kodi Addons...")
        addons_dir = xbmc.translatePath("special://home/addons/")
        
        with zipfile.ZipFile(zip_path, "r") as zip_ref:
            zip_ref.extractall(addons_dir)
            
        os.remove(zip_path)
        pDialog.close()
        
        xbmc.executebuiltin("UpdateLocalAddons")
        xbmc.executebuiltin("EnableAddon(plugin.video.elementum)")
        
        dialog.ok("Setup Complete", "Elementum installed successfully!\nYou can now watch movies online.")
    except Exception as e:
        pDialog.close()
        dialog.ok("Error", f"Failed to install Elementum: {str(e)}")

if __name__ == "__main__":
    xbmc.sleep(2000)
    install_elementum()

