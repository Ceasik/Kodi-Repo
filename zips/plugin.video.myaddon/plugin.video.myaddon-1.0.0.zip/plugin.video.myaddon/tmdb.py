import requests
import xbmcaddon
import xbmcgui

ADDON = xbmcaddon.Addon()
API_KEY = ADDON.getSetting('tmdb_api_key')
BASE_URL = "https://api.themoviedb.org/3"

def get_trending_movies():
    if not API_KEY:
        xbmcgui.Dialog().notification("TMDb Error", "Please set API Key in settings", xbmcgui.NOTIFICATION_ERROR)
        return []
        
    url = f"{BASE_URL}/trending/movie/week?api_key={API_KEY}"
    try:
        response = requests.get(url).json()
        return response.get('results', [])
    except Exception as e:
        xbmcgui.Dialog().notification("TMDb Error", str(e), xbmcgui.NOTIFICATION_ERROR)
        return []

def get_trending_shows():
    if not API_KEY:
        xbmcgui.Dialog().notification("TMDb Error", "Please set API Key in settings", xbmcgui.NOTIFICATION_ERROR)
        return []
        
    url = f"{BASE_URL}/trending/tv/week?api_key={API_KEY}"
    try:
        response = requests.get(url).json()
        return response.get('results', [])
    except Exception as e:
        xbmcgui.Dialog().notification("TMDb Error", str(e), xbmcgui.NOTIFICATION_ERROR)
        return []

def search_tmdb(query, media_type="movie"):
    if not API_KEY:
        xbmcgui.Dialog().notification("TMDb Error", "Please set API Key in settings", xbmcgui.NOTIFICATION_ERROR)
        return []
        
    url = f"{BASE_URL}/search/{media_type}?api_key={API_KEY}&query={requests.utils.quote(query)}"
    try:
        response = requests.get(url).json()
        return response.get('results', [])
    except Exception as e:
        xbmcgui.Dialog().notification("TMDb Error", str(e), xbmcgui.NOTIFICATION_ERROR)
        return []

def get_image_url(path, size="w500"):
    if not path:
        return ""
    return f"https://image.tmdb.org/t/p/{size}{path}"

def get_trailer(media_id, is_movie=True):
    if not API_KEY:
        return None
        
    media_type = "movie" if is_movie else "tv"
    url = f"{BASE_URL}/{media_type}/{media_id}/videos?api_key={API_KEY}"
    try:
        response = requests.get(url).json()
        results = response.get('results', [])
        # Look for a YouTube trailer
        for video in results:
            if video.get('site') == 'YouTube' and video.get('type') == 'Trailer':
                return video.get('key')
        
        # If no trailer, return the first video
        if results and results[0].get('site') == 'YouTube':
            return results[0].get('key')
    except:
        pass
        
    return None
