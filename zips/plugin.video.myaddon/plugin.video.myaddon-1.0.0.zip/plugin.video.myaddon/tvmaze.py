import requests
import xbmcgui

BASE_URL = "https://api.tvmaze.com"

def get_trending_shows(genre=None):
    """
    TVMaze doesn't have a direct 'trending' endpoint, 
    so we fetch the schedule for the current day in the US as a popular list.
    """
    url = f"{BASE_URL}/schedule?country=US"
    try:
        response = requests.get(url, timeout=10).json()
        
        # We need to extract the show from the episode schedule
        shows = []
        seen = set()
        
        for episode in response:
            show = episode.get('show')
            if show and show['id'] not in seen:
                # If a genre is specified, skip shows that don't have it
                if genre and genre.lower() not in [g.lower() for g in show.get('genres', [])]:
                    continue
                shows.append(show)
                seen.add(show['id'])
                
        return shows
    except Exception as e:
        xbmcgui.Dialog().notification("TVMaze Error", str(e), xbmcgui.NOTIFICATION_ERROR)
        return []

def search_shows(query):
    url = f"{BASE_URL}/search/shows?q={requests.utils.quote(query)}"
    try:
        response = requests.get(url, timeout=10).json()
        # TVMaze search returns [{'score': 0.9, 'show': {...}}, ...]
        return [item.get('show') for item in response if 'show' in item]
    except Exception as e:
        xbmcgui.Dialog().notification("TVMaze Error", str(e), xbmcgui.NOTIFICATION_ERROR)
        return []

def get_image_url(show_dict):
    """Safely extract the medium image url"""
    images = show_dict.get('image')
    if images and isinstance(images, dict):
        return images.get('medium', '')
    return ''
