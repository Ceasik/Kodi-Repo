import requests
import xbmcgui

PROVIDERS = {
    'global': 'https://iptv-org.github.io/iptv/index.m3u',
    'pluto': 'https://i.mjh.nz/PlutoTV/us.m3u8',
    'samsung': 'https://i.mjh.nz/SamsungTVPlus/us.m3u8'
}

def get_channels(provider='global'):
    """
    Fetches and parses a public M3U playlist based on the provider.
    Returns a list of dictionaries: [{'name': 'Channel Name', 'url': 'http...'}, ...]
    """
    channels = []
    url = PROVIDERS.get(provider)
    if not url:
        return channels
        
    try:
        response = requests.get(url, timeout=10)
        lines = response.text.splitlines()
        
        current_channel = None
        for line in lines:
            if line.startswith("#EXTINF:"):
                # Basic parsing: get the channel name after the last comma
                parts = line.split(",")
                if len(parts) > 1:
                    current_channel = parts[-1].strip()
            elif line.startswith("http") and current_channel:
                channels.append({'name': current_channel, 'url': line.strip()})
                current_channel = None
                
    except Exception as e:
        xbmcgui.Dialog().notification("IPTV Error", f"Failed to load playlist: {e}", xbmcgui.NOTIFICATION_ERROR)
        
    return channels
