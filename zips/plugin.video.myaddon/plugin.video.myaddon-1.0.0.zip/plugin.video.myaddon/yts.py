import requests
import xbmcgui

BASE_URL = "https://yts.mx/api/v2/list_movies.json"

def get_trending_movies(genre=None):
    """
    Fetch trending/popular movies from YTS.
    """
    url = f"{BASE_URL}?sort_by=download_count&limit=20"
    if genre:
        url += f"&genre={genre}"
    try:
        response = requests.get(url, timeout=10).json()
        if response.get('status') == 'ok':
            return response.get('data', {}).get('movies', [])
        return []
    except Exception as e:
        xbmcgui.Dialog().notification("YTS Error", str(e), xbmcgui.NOTIFICATION_ERROR)
        return []

def search_movies(query):
    """
    Search for movies on YTS.
    """
    url = f"{BASE_URL}?query_term={requests.utils.quote(query)}&limit=20"
    try:
        response = requests.get(url, timeout=10).json()
        if response.get('status') == 'ok':
            return response.get('data', {}).get('movies', [])
        return []
    except Exception as e:
        xbmcgui.Dialog().notification("YTS Error", str(e), xbmcgui.NOTIFICATION_ERROR)
        return []

def get_image_url(movie_dict):
    """
    Extract the best cover image URL from the YTS movie dictionary.
    """
    return movie_dict.get('large_cover_image', movie_dict.get('medium_cover_image', ''))

def get_trailer(movie_dict):
    """
    Extract the YouTube trailer code if available.
    """
    code = movie_dict.get('yt_trailer_code')
    if code:
        return code
    return None
