import sys
import urllib.parse
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import tmdb
import tvmaze
import iptv
import free_providers
import extractor

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
args = urllib.parse.parse_qs(sys.argv[2][1:])

def build_url(query):
    return base_url + '?' + urllib.parse.urlencode(query)

def list_main_menu():
    categories = [
        {'name': 'Israel TV (Fishenzon)', 'action': 'open_israel_tv'},
        {'name': 'Live TV (IPTV)', 'action': 'live_tv_providers'},
        {'name': 'Movies (TMDb)', 'action': 'trending_movies'},
        {'name': 'TV Shows (TVMaze)', 'action': 'trending_shows'},
        {'name': 'Search', 'action': 'search_menu'},
        {'name': 'Open Settings', 'action': 'open_settings'}
    ]
    
    for category in categories:
        url = build_url(category)
        is_folder = category['action'] != 'open_settings'
        list_item = xbmcgui.ListItem(label=category['name'])
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=list_item, isFolder=is_folder)
        
    xbmcplugin.endOfDirectory(addon_handle)

def open_settings():
    xbmcaddon.Addon().openSettings()

def live_tv_providers():
    providers = [
        {'name': 'Global Channels (iptv-org)', 'provider': 'global'},
        {'name': 'Pluto TV (Free Ad-Supported)', 'provider': 'pluto'},
        {'name': 'Samsung TV Plus', 'provider': 'samsung'}
    ]
    
    for prov in providers:
        url = build_url({'action': 'live_tv_menu', 'provider': prov['provider']})
        list_item = xbmcgui.ListItem(label=prov['name'])
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=list_item, isFolder=True)
        
    xbmcplugin.endOfDirectory(addon_handle)

def live_tv_menu():
    provider = args.get('provider', ['global'])[0]
    
    pDialog = xbmcgui.DialogProgress()
    pDialog.create('Loading IPTV', 'Fetching channels...')
    pDialog.update(50)
    
    channels = iptv.get_channels(provider)
    
    pDialog.update(100)
    pDialog.close()
    
    if not channels:
        xbmcgui.Dialog().notification("No Channels", "Failed to load provider list.", xbmcgui.NOTIFICATION_WARNING)
        xbmcplugin.endOfDirectory(addon_handle)
        return
        
    for channel in channels:
        url = build_url({'action': 'play_video', 'video_url': channel['url']})
        list_item = xbmcgui.ListItem(label=channel['name'])
        list_item.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=list_item, isFolder=False)
        
    xbmcplugin.endOfDirectory(addon_handle)

def search_menu():
    dialog = xbmcgui.Dialog()
    choice = dialog.select("Search", ["Search Movies (TMDb)", "Search TV Shows (TVMaze)"])
    
    if choice == 0:
        keyboard = xbmcgui.Keyboard('', 'Search for a Movie')
        keyboard.doModal()
        if keyboard.isConfirmed() and keyboard.getText():
            results = tmdb.search_tmdb(keyboard.getText(), "movie")
            display_tmdb_movies(results)
        else:
            xbmcplugin.endOfDirectory(addon_handle)
    elif choice == 1:
        keyboard = xbmcgui.Keyboard('', 'Search for a TV Show')
        keyboard.doModal()
        if keyboard.isConfirmed() and keyboard.getText():
            results = tvmaze.search_shows(keyboard.getText())
            display_tvmaze_shows(results)
        else:
            xbmcplugin.endOfDirectory(addon_handle)
    else:
        xbmcplugin.endOfDirectory(addon_handle)

def list_trending_movies():
    results = tmdb.get_trending_movies()
    display_tmdb_movies(results)

def list_trending_shows():
    results = tvmaze.get_trending_shows()
    display_tvmaze_shows(results)

def display_tmdb_movies(results):
    if not results:
        xbmcgui.Dialog().notification("No Results", "Check TMDb API Key in settings.", xbmcgui.NOTIFICATION_WARNING)
        xbmcplugin.endOfDirectory(addon_handle)
        return
        
    for item in results:
        title = item.get('title')
        media_id = item.get('id')
        year = ""
        date_str = item.get('release_date')
        if date_str:
            year = date_str.split('-')[0]
            
        display_title = f"{title} ({year})" if year else title
        
        # Action is Smart Play using Free APIs
        url = build_url({
            'action': 'smart_play_movie',
            'media_id': media_id,
            'title': title
        })
        
        list_item = xbmcgui.ListItem(label=display_title)
        
        poster_path = item.get('poster_path')
        if poster_path:
            list_item.setArt({'thumb': tmdb.get_image_url(poster_path),
                              'poster': tmdb.get_image_url(poster_path)})
                              
        list_item.setInfo('video', {'title': title, 'year': int(year) if year else 0, 'plot': item.get('overview', '')})
        list_item.setProperty('IsPlayable', 'true')
        
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=list_item, isFolder=False)
        
    xbmcplugin.endOfDirectory(addon_handle)

def display_tvmaze_shows(results):
    if not results:
        xbmcgui.Dialog().notification("No Results", "No shows found.", xbmcgui.NOTIFICATION_WARNING)
        xbmcplugin.endOfDirectory(addon_handle)
        return
        
    for item in results:
        title = item.get('name')
        url = build_url({'action': 'show_info', 'title': title})
        list_item = xbmcgui.ListItem(label=title)
        
        image_url = tvmaze.get_image_url(item)
        if image_url:
            list_item.setArt({'thumb': image_url, 'poster': image_url})
            
        summary = item.get('summary', '').replace('<p>', '').replace('</p>', '').replace('<b>', '').replace('</b>', '')
        list_item.setInfo('video', {'title': title, 'plot': summary})
        
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=list_item, isFolder=False)
        
    xbmcplugin.endOfDirectory(addon_handle)

def show_info():
    title = args.get('title', [''])[0]
    xbmcgui.Dialog().ok(title, "TV Episodes via Free APIs coming in a future update.")

def smart_play_movie():
    title = args.get('title', [''])[0]
    media_id = args.get('media_id', [''])[0]
    
    pDialog = xbmcgui.DialogProgress()
    pDialog.create('Smart Play', 'Searching Free Provider APIs...')
    pDialog.update(25)
    
    # Get the web player URLs from our free providers
    embed_urls = free_providers.get_embed_urls(media_id)
    
    playable_stream = None
    
    # Try to extract a stream from one of the free APIs
    for index, embed_url in enumerate(embed_urls):
        pDialog.update(25 + int((index / len(embed_urls)) * 50), f'Extracting stream from Provider {index+1}...')
        stream = extractor.extract_video_link(embed_url)
        if stream:
            playable_stream = stream
            break
            
    pDialog.update(100)
    pDialog.close()
    
    if playable_stream:
        xbmcgui.Dialog().notification("Found Stream", "Playing from Free API", xbmcgui.NOTIFICATION_INFO)
        play_item = xbmcgui.ListItem(path=playable_stream)
        xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
    else:
        xbmcgui.Dialog().notification("Extraction Failed", "Playing YouTube Trailer instead", xbmcgui.NOTIFICATION_INFO)
        # Fallback to Trailer
        trailer_id = tmdb.get_trailer(media_id, is_movie=True)
        if trailer_id:
            youtube_url = f"plugin://plugin.video.youtube/play/?video_id={trailer_id}"
            play_item = xbmcgui.ListItem(path=youtube_url)
            xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
        else:
            xbmcgui.Dialog().notification("No Trailer", "Could not find a trailer.", xbmcgui.NOTIFICATION_WARNING)
            xbmcplugin.setResolvedUrl(addon_handle, False, listitem=xbmcgui.ListItem())

def play_video():
    video_url = args.get('video_url', [''])[0]
    play_item = xbmcgui.ListItem(path=video_url)
    xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)

def open_israel_tv():
    # Use Kodi builtin to run the idanplus plugin
    xbmc.executebuiltin('RunPlugin(plugin://plugin.video.idanplus/)')
    
def router(paramstring):
    action = args.get('action', [None])[0]
    
    if action is None:
        list_main_menu()
    elif action == 'open_israel_tv':
        open_israel_tv()
    elif action == 'open_settings':
        open_settings()
    elif action == 'live_tv_providers':
        live_tv_providers()
    elif action == 'live_tv_menu':
        live_tv_menu()
    elif action == 'trending_movies':
        list_trending_movies()
    elif action == 'trending_shows':
        list_trending_shows()
    elif action == 'search_menu':
        search_menu()
    elif action == 'smart_play_movie':
        smart_play_movie()
    elif action == 'play_video':
        play_video()
    elif action == 'show_info':
        show_info()

if __name__ == '__main__':
    router(sys.argv[2][1:])
