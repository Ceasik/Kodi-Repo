import sys
import urllib.parse
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import tmdb
import iptv
import free_providers
import extractor

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
args = urllib.parse.parse_qs(sys.argv[2][1:])

def build_url(query):
    return base_url + '?' + urllib.parse.urlencode(query)

def list_main_menu():
    categories = [
        {'name': 'Israel TV (Fishenzon)', 'action': 'open_israel_tv'},
        {'name': 'Live TV (IPTV)', 'action': 'live_tv_categories'},
        {'name': 'Movies', 'action': 'movie_categories'},
        {'name': 'TV Shows', 'action': 'show_categories'},
        {'name': 'Search', 'action': 'search_menu'},
        {'name': 'Open Settings', 'action': 'open_settings'}
    ]
    
    for category in categories:
        url = build_url(category)
        is_folder = category['action'] != 'open_settings'
        list_item = xbmcgui.ListItem(label=category['name'])
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=list_item, isFolder=is_folder)
        
    xbmcplugin.endOfDirectory(addon_handle)

def open_settings():
    xbmcaddon.Addon().openSettings()

def live_tv_categories():
    categories = [
        {'name': 'All Global Channels', 'provider': 'global'},
        {'name': 'News', 'provider': 'news'},
        {'name': 'Sports', 'provider': 'sports'},
        {'name': 'Business & Finance', 'provider': 'business'},
        {'name': 'Entertainment', 'provider': 'entertainment'},
        {'name': 'Movies', 'provider': 'movies'},
        {'name': 'Pluto TV (Free Ad-Supported)', 'provider': 'pluto'},
        {'name': 'Samsung TV Plus', 'provider': 'samsung'}
    ]
    
    for cat in categories:
        url = build_url({'action': 'live_tv_menu', 'provider': cat['provider']})
        list_item = xbmcgui.ListItem(label=cat['name'])
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=list_item, isFolder=True)
        
    xbmcplugin.endOfDirectory(addon_handle)

def movie_categories():
    categories = [
        {'name': 'Trending', 'genre': ''},
        {'name': 'Action', 'genre': '28'},
        {'name': 'Comedy', 'genre': '35'},
        {'name': 'Drama', 'genre': '18'},
        {'name': 'Horror', 'genre': '27'},
        {'name': 'Romance', 'genre': '10749'},
        {'name': 'Sci-Fi', 'genre': '878'}
    ]
    
    for cat in categories:
        url = build_url({'action': 'list_movies', 'genre': cat['genre'], 'page': '1'})
        list_item = xbmcgui.ListItem(label=cat['name'])
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=list_item, isFolder=True)
        
    xbmcplugin.endOfDirectory(addon_handle)

def show_categories():
    categories = [
        {'name': 'Trending Today', 'genre': ''},
        {'name': 'Action & Adventure', 'genre': '10759'},
        {'name': 'Comedy', 'genre': '35'},
        {'name': 'Drama', 'genre': '18'},
        {'name': 'Crime', 'genre': '80'},
        {'name': 'Mystery', 'genre': '9648'}
    ]
    
    for cat in categories:
        url = build_url({'action': 'list_shows', 'genre': cat['genre'], 'page': '1'})
        list_item = xbmcgui.ListItem(label=cat['name'])
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=list_item, isFolder=True)
        
    xbmcplugin.endOfDirectory(addon_handle)

def live_tv_menu():
    provider = args.get('provider', ['global'])[0]
    
    pDialog = xbmcgui.DialogProgress()
    pDialog.create('Loading IPTV', 'Fetching channels...')
    pDialog.update(50)
    
    channels = iptv.get_channels(provider)
    
    pDialog.update(100)
    pDialog.close()
    
    if not channels:
        xbmcgui.Dialog().notification("No Channels", "Failed to load provider list.", xbmcgui.NOTIFICATION_WARNING)
        xbmcplugin.endOfDirectory(addon_handle)
        return
        
    for channel in channels:
        url = build_url({'action': 'play_video', 'video_url': channel['url']})
        list_item = xbmcgui.ListItem(label=channel['name'])
        list_item.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=list_item, isFolder=False)
        
    xbmcplugin.endOfDirectory(addon_handle)

def search_menu():
    dialog = xbmcgui.Dialog()
    choice = dialog.select("Search", ["Search Movies", "Search TV Shows", "Search by Actor"])
    
    if choice == 0:
        keyboard = xbmcgui.Keyboard('', 'Search for a Movie')
        keyboard.doModal()
        if keyboard.isConfirmed() and keyboard.getText():
            url = build_url({'action': 'search_movies', 'query': keyboard.getText(), 'page': '1'})
            xbmc.executebuiltin(f'Container.Update({url})')
    elif choice == 1:
        keyboard = xbmcgui.Keyboard('', 'Search for a TV Show')
        keyboard.doModal()
        if keyboard.isConfirmed() and keyboard.getText():
            url = build_url({'action': 'search_shows', 'query': keyboard.getText(), 'page': '1'})
            xbmc.executebuiltin(f'Container.Update({url})')
    elif choice == 2:
        keyboard = xbmcgui.Keyboard('', 'Search by Actor')
        keyboard.doModal()
        if keyboard.isConfirmed() and keyboard.getText():
            url = build_url({'action': 'search_actor', 'query': keyboard.getText(), 'page': '1'})
            xbmc.executebuiltin(f'Container.Update({url})')
    else:
        xbmcplugin.endOfDirectory(addon_handle)

def display_media(results, media_type, next_page_params=None):
    if not results:
        xbmcgui.Dialog().notification("No Results", "Could not find any media.", xbmcgui.NOTIFICATION_WARNING)
        xbmcplugin.endOfDirectory(addon_handle)
        return
        
    for item in results:
        # Determine if it's a movie or show based on the object or passed media_type
        # In combined_credits, media_type is inside the item
        item_media_type = item.get('media_type', media_type)
        
        title = item.get('title') or item.get('name')
        media_id = item.get('id')
        date_str = item.get('release_date') or item.get('first_air_date')
        year = date_str.split('-')[0] if date_str else ""
            
        display_title = f"{title} ({year})" if year else title
        
        if item_media_type == "movie":
            url = build_url({
                'action': 'smart_play_movie',
                'tmdb_id': media_id,
                'title': title
            })
            is_folder = False
        else:
            url = build_url({
                'action': 'list_seasons', 
                'tmdb_id': media_id,
                'title': title
            })
            is_folder = True
        
        list_item = xbmcgui.ListItem(label=display_title)
        
        poster_path = item.get('poster_path')
        if poster_path:
            list_item.setArt({
                'thumb': tmdb.get_image_url(poster_path),
                'poster': tmdb.get_image_url(poster_path)
            })
            
        backdrop = item.get('backdrop_path')
        if backdrop:
            list_item.setArt({'fanart': tmdb.get_image_url(backdrop, 'w1280')})
                              
        list_item.setInfo('video', {
            'title': title, 
            'year': int(year) if year else 0, 
            'plot': item.get('overview', ''),
            'rating': item.get('vote_average', 0.0)
        })
        
        if item_media_type == "movie":
            list_item.setProperty('IsPlayable', 'true')
        
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=list_item, isFolder=is_folder)
        
    if next_page_params:
        next_url = build_url(next_page_params)
        next_item = xbmcgui.ListItem(label="Next Page ➔")
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=next_url, listitem=next_item, isFolder=True)
        
    xbmcplugin.endOfDirectory(addon_handle)

def list_movies():
    genre = args.get('genre', [''])[0]
    page = int(args.get('page', ['1'])[0])
    
    if genre:
        results = tmdb.get_by_genre("movie", genre, page)
    else:
        results = tmdb.get_trending("movie", page)
        
    next_params = {'action': 'list_movies', 'genre': genre, 'page': str(page + 1)}
    display_media(results, "movie", next_params)

def list_shows():
    genre = args.get('genre', [''])[0]
    page = int(args.get('page', ['1'])[0])
    
    if genre:
        results = tmdb.get_by_genre("tv", genre, page)
    else:
        results = tmdb.get_trending("tv", page)
        
    next_params = {'action': 'list_shows', 'genre': genre, 'page': str(page + 1)}
    display_media(results, "tv", next_params)

def do_search_movies():
    query = args.get('query', [''])[0]
    page = int(args.get('page', ['1'])[0])
    results = tmdb.search(query, "movie", page)
    next_params = {'action': 'search_movies', 'query': query, 'page': str(page + 1)} if len(results) == 20 else None
    display_media(results, "movie", next_params)

def do_search_shows():
    query = args.get('query', [''])[0]
    page = int(args.get('page', ['1'])[0])
    results = tmdb.search(query, "tv", page)
    next_params = {'action': 'search_shows', 'query': query, 'page': str(page + 1)} if len(results) == 20 else None
    display_media(results, "tv", next_params)

def do_search_actor():
    query = args.get('query', [''])[0]
    page = int(args.get('page', ['1'])[0])
    results = tmdb.search_by_actor(query, page)
    next_params = {'action': 'search_actor', 'query': query, 'page': str(page + 1)} if len(results) == 20 else None
    display_media(results, "movie", next_params) # Mixed media

def list_seasons():
    tmdb_id = args.get('tmdb_id', [''])[0]
    title = args.get('title', [''])[0]
    details = tmdb.get_tv_details(tmdb_id)
    seasons = details.get('seasons', [])
    for season in seasons:
        season_num = season.get('season_number')
        season_name = season.get('name')
        poster_path = season.get('poster_path')
        
        url = build_url({
            'action': 'list_episodes',
            'tmdb_id': tmdb_id,
            'season': season_num,
            'title': f"{title} - {season_name}"
        })
        list_item = xbmcgui.ListItem(label=season_name)
        if poster_path:
            list_item.setArt({
                'thumb': tmdb.get_image_url(poster_path),
                'poster': tmdb.get_image_url(poster_path)
            })
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=list_item, isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle)

def list_episodes():
    tmdb_id = args.get('tmdb_id', [''])[0]
    season = args.get('season', [''])[0]
    title = args.get('title', [''])[0]
    
    details = tmdb.get_season_details(tmdb_id, season)
    episodes = details.get('episodes', [])
    
    for episode in episodes:
        ep_num = episode.get('episode_number')
        ep_name = episode.get('name')
        still_path = episode.get('still_path')
        overview = episode.get('overview', '')
        
        display_title = f"{ep_num}. {ep_name}"
        
        url = build_url({
            'action': 'smart_play_tv',
            'tmdb_id': tmdb_id,
            'season': season,
            'episode': ep_num,
            'title': f"{title} s{season}e{ep_num}"
        })
        
        list_item = xbmcgui.ListItem(label=display_title)
        if still_path:
            list_item.setArt({'thumb': tmdb.get_image_url(still_path)})
        list_item.setInfo('video', {'title': display_title, 'plot': overview, 'season': int(season), 'episode': int(ep_num)})
        list_item.setProperty('IsPlayable', 'true')
        
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=list_item, isFolder=False)
    xbmcplugin.endOfDirectory(addon_handle)

def smart_play_tv():
    title = args.get('title', [''])[0]
    tmdb_id = args.get('tmdb_id', [''])[0]
    season = args.get('season', [''])[0]
    episode = args.get('episode', [''])[0]
    
    pDialog = xbmcgui.DialogProgress()
    pDialog.create('Smart Play', 'Searching Free Provider APIs...')
    pDialog.update(25)
    
    embed_urls = free_providers.get_tv_embed_urls(tmdb_id, season, episode)
    
    playable_stream = None
    
    for index, embed_url in enumerate(embed_urls):
        pDialog.update(25 + int((index / len(embed_urls)) * 50), f'Extracting stream from Provider {index+1}...')
        stream = extractor.extract_video_link(embed_url)
        if stream:
            playable_stream = stream
            break
            
    pDialog.update(100)
    pDialog.close()
    
    if playable_stream:
        xbmcgui.Dialog().notification("Found Stream", "Playing from Free API", xbmcgui.NOTIFICATION_INFO)
        play_item = xbmcgui.ListItem(path=playable_stream)
        xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
    else:
        xbmcgui.Dialog().notification("Extraction Failed", "Could not extract a stream.", xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.setResolvedUrl(addon_handle, False, listitem=xbmcgui.ListItem())

def smart_play_movie():
    title = args.get('title', [''])[0]
    tmdb_id = args.get('tmdb_id', [''])[0]
    
    pDialog = xbmcgui.DialogProgress()
    pDialog.create('Smart Play', 'Searching Free Provider APIs...')
    pDialog.update(25)
    
    # Get the web player URLs from our free providers
    embed_urls = free_providers.get_embed_urls(tmdb_id)
    
    playable_stream = None
    
    # Try to extract a stream from one of the free APIs
    for index, embed_url in enumerate(embed_urls):
        pDialog.update(25 + int((index / len(embed_urls)) * 50), f'Extracting stream from Provider {index+1}...')
        stream = extractor.extract_video_link(embed_url)
        if stream:
            playable_stream = stream
            break
            
    pDialog.update(100)
    pDialog.close()
    
    if playable_stream:
        xbmcgui.Dialog().notification("Found Stream", "Playing from Free API", xbmcgui.NOTIFICATION_INFO)
        play_item = xbmcgui.ListItem(path=playable_stream)
        xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
    else:
        xbmcgui.Dialog().notification("Extraction Failed", "Could not extract a stream.", xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.setResolvedUrl(addon_handle, False, listitem=xbmcgui.ListItem())

def play_video():
    video_url = args.get('video_url', [''])[0]
    play_item = xbmcgui.ListItem(path=video_url)
    xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)

def open_israel_tv():
    xbmc.executebuiltin('RunPlugin(plugin://plugin.video.idanplus/)')
    
def router(paramstring):
    action = args.get('action', [None])[0]
    
    if action is None:
        list_main_menu()
    elif action == 'open_israel_tv':
        open_israel_tv()
    elif action == 'open_settings':
        open_settings()
    elif action == 'live_tv_categories':
        live_tv_categories()
    elif action == 'movie_categories':
        movie_categories()
    elif action == 'show_categories':
        show_categories()
    elif action == 'live_tv_menu':
        live_tv_menu()
    elif action == 'list_movies':
        list_movies()
    elif action == 'list_shows':
        list_shows()
    elif action == 'search_menu':
        search_menu()
    elif action == 'search_movies':
        do_search_movies()
    elif action == 'search_shows':
        do_search_shows()
    elif action == 'search_actor':
        do_search_actor()
    elif action == 'smart_play_movie':
        smart_play_movie()
    elif action == 'smart_play_tv':
        smart_play_tv()
    elif action == 'list_seasons':
        list_seasons()
    elif action == 'list_episodes':
        list_episodes()
    elif action == 'play_video':
        play_video()

if __name__ == '__main__':
    router(sys.argv[2][1:])
