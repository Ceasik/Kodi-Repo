import requests

# Examples of popular free APIs that provide iframes based on IMDB ID
# Note: These are for educational purposes. 
PROVIDERS = {
    'vidsrc': 'https://vidsrc.me/embed/movie?imdb={imdb_id}',
    'autoembed': 'https://autoembed.to/movie/imdb/{imdb_id}',
    'multiembed': 'https://multiembed.mov/directstream.php?video_id={imdb_id}'
}

def get_embed_urls(imdb_id):
    """
    Returns a list of embed URLs for a given IMDB ID.
    """
    urls = []
    for name, base_url in PROVIDERS.items():
        urls.append(base_url.format(imdb_id=imdb_id))
    return urls
