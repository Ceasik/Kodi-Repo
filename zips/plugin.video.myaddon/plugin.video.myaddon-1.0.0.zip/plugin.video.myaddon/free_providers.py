import requests

# Examples of popular free APIs that provide iframes based on TMDB ID
# Note: These are for educational purposes. 
PROVIDERS = {
    'vidsrc': 'https://vidsrc.me/embed/movie?tmdb={tmdb_id}',
    'autoembed': 'https://autoembed.to/movie/tmdb/{tmdb_id}',
    'multiembed': 'https://multiembed.mov/directstream.php?video_id={tmdb_id}&tmdb=1'
}

def get_embed_urls(tmdb_id):
    """
    Returns a list of embed URLs for a given TMDB ID.
    """
    urls = []
    for name, base_url in PROVIDERS.items():
        urls.append(base_url.format(tmdb_id=tmdb_id))
    return urls
