import requests

# Examples of popular free APIs that provide iframes based on TMDB ID
# Note: These are for educational purposes. 
PROVIDERS = {
    'vidsrc': 'https://vidsrc.me/embed/movie?tmdb={tmdb_id}',
    'cineby': 'https://cineby.app/movie/{tmdb_id}',
    'autoembed': 'https://autoembed.to/movie/tmdb/{tmdb_id}',
    'multiembed': 'https://multiembed.mov/directstream.php?video_id={tmdb_id}&tmdb=1'
}

def get_embed_urls(tmdb_id):
    """
    Returns a list of embed URLs for a given TMDB ID.
    """
    urls = []
    for name, base_url in PROVIDERS.items():
        urls.append(base_url.format(tmdb_id=tmdb_id))
    return urls

TV_PROVIDERS = {
    'vidsrc': 'https://vidsrc.me/embed/tv?tmdb={tmdb_id}&season={season}&episode={episode}',
    'cineby': 'https://cineby.app/tv/{tmdb_id}/{season}/{episode}',
    'autoembed': 'https://autoembed.to/tv/tmdb/{tmdb_id}-{season}-{episode}',
    'multiembed': 'https://multiembed.mov/directstream.php?video_id={tmdb_id}&tmdb=1&s={season}&e={episode}'
}

def get_tv_embed_urls(tmdb_id, season, episode):
    """
    Returns a list of embed URLs for a given TV show episode.
    """
    urls = []
    for name, base_url in TV_PROVIDERS.items():
        urls.append(base_url.format(tmdb_id=tmdb_id, season=season, episode=episode))
    return urls
